@javax.xml.bind.annotation.XmlSchema(namespace = "http://fileServer.server/")
package server.fileServer.services;
