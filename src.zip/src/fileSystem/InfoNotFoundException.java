package fileSystem;

public class InfoNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public InfoNotFoundException(String message) {
		super(message);
	}
}
